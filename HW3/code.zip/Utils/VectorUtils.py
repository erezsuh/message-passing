def multiply_vectors(v1, v2):
    return [a * b for a, b in zip(v1, v2)]